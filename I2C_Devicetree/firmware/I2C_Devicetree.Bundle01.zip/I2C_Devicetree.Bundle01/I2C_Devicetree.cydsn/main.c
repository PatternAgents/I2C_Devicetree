/**
 ******************************************************************************
    @file        main.c
    @author      Tom Moxon
    @version     0.0.1
    @date        2013-06-27
    @copyright   PatternAgents, LLC
    @brief       This file provides the Main program entry point/function.
    @mainpage    RSVP Platform Firmware Documentation
    @section     main_intro Introduction
    @par
    \n
    @par
    @section    main_theory Theory of Operation
    @par
    The I2C_Devicetree reference design project uses a \n
    programmable System-on-Chip (SoC) with a Cortex-M0 CPU, in a small 28 Pin TSSOP package,\n 
    to emulate an I2C EEPROM using the FLASH memory of the SoC, \n
    which creates an "intelligent memory" device. \n
    The I2C_Devicetree reference design project is intended to \n
    make it easier for people to create their own custom expansion boards for \n 
    Beaglebone, Raspberry Pi, FMC/IPMI, and other platforms that \n
    require the use of a I2C EEPROM for automatic product identification, \n 
    pin mapping, and configuration. \n
    \n
    @par
    @section    main_packages Firmware Packages 
    @par
    The RSVP Firmware utilizes several external software packages \n
	with various licenses. Check each package for redistribution terms. \n
    @par
    \n
	@par
	Cypress Creator Compiler/Libraries : \n
	GCC/Keil Compiler/Libraries : \n
	TBD: (audit any other third-party code for licensing terms) \n
	@par

 ******************************************************************************
*/

/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include "rsvp_conf.h"
#include <rsvp_platform.h>
#include <rsvp_adc.h>
#include <rsvp_cli.h>
#include <rsvp_io.h>

/*-----------------------------------------------------------------------------*/
/** @defgroup main main
  * @{
  */
#define RSVP_DEBUG 1 /**< Define to a nonzero value to enable debugging messages    */
#define RSVP_TEST  1 /**< Define to a nonzero value to enable internal test modes   */

uint8 I2C_RAMBuffer[16];

/*-----------------------------------------------------------------------------*/
/**
  * @fn         int main(void)
  * @brief      Firmware Main Entry Point
  * @brief      The main entry point
  * @param      None.
  * @retval     int (Main never returns, a return of int is used to indicate failure)
  */
int main(void)
{
  rsvp_RetCode_t rsvp_RetVal;

  /* Start the Platform Stack and test for success */ 	
  if ((rsvp_RetVal = rsvp_platform_Start()) == RSVP_SUCCESS) {
	/* main - infinite loop */
    
    /* turn all LED's off */
    USER_LED_1_Write(0);    
    USER_LED_2_Write(0);
    USER_LED_3_Write(0);

    I2C_1_EzI2CSetBuffer1(16, 8, (void *) I2C_RAMBuffer);
    I2C_1_Start();
 
    for(;;)
    {
        USER_LED_1_Write(~USER_LED_1_Read());
        CyDelay(500);
        USER_LED_2_Write(~USER_LED_2_Read());
        CyDelay(500);
        USER_LED_3_Write(~USER_LED_3_Read());
        CyDelay(500);

		/* most operations are interrupt driven... */
        
		#if (RSVP_USE_ADC_1 == TRUE)
	  		rsvp_ADC_Poll();
		#endif

		#if (RSVP_USE_CLI == TRUE)
	 	    rsvp_CLI_Poll();
		#endif
		
	}
  } else {
	/* unable to start hardware platform properly      */
    /* stop the platform and enter an infinite loop... */
    rsvp_RetVal = rsvp_platform_Stop();
    for(;;)
    {
		/* enter an infinite loop - add default platform error code here... */
	    /* @todo - set an LED blink rate for error code */
    }
  }
}

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen main group.
  *    @}
*/

/* End of main.c */
