/*******************************************************************************
* File Name: TIMER_2.h
* Version 2.0
*
* Description:
*  This file provides constants and parameter values for the TIMER_2
*  component.
*
* Note:
*  None
*
********************************************************************************
* Copyright 2013-2014, Cypress Semiconductor Corporation.  All rights reserved.
* You may use this file only in accordance with the license, terms, conditions,
* disclaimers, and limitations in the end user license agreement accompanying
* the software package with which this file was provided.
*******************************************************************************/

#if !defined(CY_TCPWM_TIMER_2_H)
#define CY_TCPWM_TIMER_2_H


#include "CyLib.h"
#include "cytypes.h"
#include "cyfitter.h"


/*******************************************************************************
* Internal Type defines
*******************************************************************************/

/* Structure to save state before go to sleep */
typedef struct
{
    uint8  enableState;
} TIMER_2_BACKUP_STRUCT;


/*******************************************************************************
* Variables
*******************************************************************************/
extern uint8  TIMER_2_initVar;


/***************************************
*   Conditional Compilation Parameters
****************************************/

#define TIMER_2_CY_TCPWM_V2                    (CYIPBLOCK_m0s8tcpwm_VERSION == 2u)
#define TIMER_2_CY_TCPWM_4000                  (CY_PSOC4_4000)

/* TCPWM Configuration */
#define TIMER_2_CONFIG                         (1lu)

/* Quad Mode */
/* Parameters */
#define TIMER_2_QUAD_ENCODING_MODES            (0lu)

/* Signal modes */
#define TIMER_2_QUAD_INDEX_SIGNAL_MODE         (0lu)
#define TIMER_2_QUAD_PHIA_SIGNAL_MODE          (3lu)
#define TIMER_2_QUAD_PHIB_SIGNAL_MODE          (3lu)
#define TIMER_2_QUAD_STOP_SIGNAL_MODE          (0lu)

/* Signal present */
#define TIMER_2_QUAD_INDEX_SIGNAL_PRESENT      (0lu)
#define TIMER_2_QUAD_STOP_SIGNAL_PRESENT       (0lu)

/* Interrupt Mask */
#define TIMER_2_QUAD_INTERRUPT_MASK            (1lu)

/* Timer/Counter Mode */
/* Parameters */
#define TIMER_2_TC_RUN_MODE                    (0lu)
#define TIMER_2_TC_COUNTER_MODE                (0lu)
#define TIMER_2_TC_COMP_CAP_MODE               (2lu)
#define TIMER_2_TC_PRESCALER                   (0lu)

/* Signal modes */
#define TIMER_2_TC_RELOAD_SIGNAL_MODE          (0lu)
#define TIMER_2_TC_COUNT_SIGNAL_MODE           (3lu)
#define TIMER_2_TC_START_SIGNAL_MODE           (0lu)
#define TIMER_2_TC_STOP_SIGNAL_MODE            (0lu)
#define TIMER_2_TC_CAPTURE_SIGNAL_MODE         (0lu)

/* Signal present */
#define TIMER_2_TC_RELOAD_SIGNAL_PRESENT       (0lu)
#define TIMER_2_TC_COUNT_SIGNAL_PRESENT        (0lu)
#define TIMER_2_TC_START_SIGNAL_PRESENT        (0lu)
#define TIMER_2_TC_STOP_SIGNAL_PRESENT         (0lu)
#define TIMER_2_TC_CAPTURE_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define TIMER_2_TC_INTERRUPT_MASK              (1lu)

/* PWM Mode */
/* Parameters */
#define TIMER_2_PWM_KILL_EVENT                 (0lu)
#define TIMER_2_PWM_STOP_EVENT                 (0lu)
#define TIMER_2_PWM_MODE                       (4lu)
#define TIMER_2_PWM_OUT_N_INVERT               (0lu)
#define TIMER_2_PWM_OUT_INVERT                 (0lu)
#define TIMER_2_PWM_ALIGN                      (0lu)
#define TIMER_2_PWM_RUN_MODE                   (0lu)
#define TIMER_2_PWM_DEAD_TIME_CYCLE            (0lu)
#define TIMER_2_PWM_PRESCALER                  (0lu)

/* Signal modes */
#define TIMER_2_PWM_RELOAD_SIGNAL_MODE         (0lu)
#define TIMER_2_PWM_COUNT_SIGNAL_MODE          (3lu)
#define TIMER_2_PWM_START_SIGNAL_MODE          (0lu)
#define TIMER_2_PWM_STOP_SIGNAL_MODE           (0lu)
#define TIMER_2_PWM_SWITCH_SIGNAL_MODE         (0lu)

/* Signal present */
#define TIMER_2_PWM_RELOAD_SIGNAL_PRESENT      (0lu)
#define TIMER_2_PWM_COUNT_SIGNAL_PRESENT       (0lu)
#define TIMER_2_PWM_START_SIGNAL_PRESENT       (0lu)
#define TIMER_2_PWM_STOP_SIGNAL_PRESENT        (0lu)
#define TIMER_2_PWM_SWITCH_SIGNAL_PRESENT      (0lu)

/* Interrupt Mask */
#define TIMER_2_PWM_INTERRUPT_MASK             (1lu)


/***************************************
*    Initial Parameter Constants
***************************************/

/* Timer/Counter Mode */
#define TIMER_2_TC_PERIOD_VALUE                (65535lu)
#define TIMER_2_TC_COMPARE_VALUE               (65535lu)
#define TIMER_2_TC_COMPARE_BUF_VALUE           (65535lu)
#define TIMER_2_TC_COMPARE_SWAP                (0lu)

/* PWM Mode */
#define TIMER_2_PWM_PERIOD_VALUE               (65535lu)
#define TIMER_2_PWM_PERIOD_BUF_VALUE           (65535lu)
#define TIMER_2_PWM_PERIOD_SWAP                (0lu)
#define TIMER_2_PWM_COMPARE_VALUE              (65535lu)
#define TIMER_2_PWM_COMPARE_BUF_VALUE          (65535lu)
#define TIMER_2_PWM_COMPARE_SWAP               (0lu)


/***************************************
*    Enumerated Types and Parameters
***************************************/

#define TIMER_2__LEFT 0
#define TIMER_2__RIGHT 1
#define TIMER_2__CENTER 2
#define TIMER_2__ASYMMETRIC 3

#define TIMER_2__X1 0
#define TIMER_2__X2 1
#define TIMER_2__X4 2

#define TIMER_2__PWM 4
#define TIMER_2__PWM_DT 5
#define TIMER_2__PWM_PR 6

#define TIMER_2__INVERSE 1
#define TIMER_2__DIRECT 0

#define TIMER_2__CAPTURE 2
#define TIMER_2__COMPARE 0

#define TIMER_2__TRIG_LEVEL 3
#define TIMER_2__TRIG_RISING 0
#define TIMER_2__TRIG_FALLING 1
#define TIMER_2__TRIG_BOTH 2

#define TIMER_2__INTR_MASK_TC 1
#define TIMER_2__INTR_MASK_CC_MATCH 2
#define TIMER_2__INTR_MASK_NONE 0
#define TIMER_2__INTR_MASK_TC_CC 3

#define TIMER_2__UNCONFIG 8
#define TIMER_2__TIMER 1
#define TIMER_2__QUAD 3
#define TIMER_2__PWM_SEL 7

#define TIMER_2__COUNT_UP 0
#define TIMER_2__COUNT_DOWN 1
#define TIMER_2__COUNT_UPDOWN0 2
#define TIMER_2__COUNT_UPDOWN1 3


/* Prescaler */
#define TIMER_2_PRESCALE_DIVBY1                ((uint32)(0u << TIMER_2_PRESCALER_SHIFT))
#define TIMER_2_PRESCALE_DIVBY2                ((uint32)(1u << TIMER_2_PRESCALER_SHIFT))
#define TIMER_2_PRESCALE_DIVBY4                ((uint32)(2u << TIMER_2_PRESCALER_SHIFT))
#define TIMER_2_PRESCALE_DIVBY8                ((uint32)(3u << TIMER_2_PRESCALER_SHIFT))
#define TIMER_2_PRESCALE_DIVBY16               ((uint32)(4u << TIMER_2_PRESCALER_SHIFT))
#define TIMER_2_PRESCALE_DIVBY32               ((uint32)(5u << TIMER_2_PRESCALER_SHIFT))
#define TIMER_2_PRESCALE_DIVBY64               ((uint32)(6u << TIMER_2_PRESCALER_SHIFT))
#define TIMER_2_PRESCALE_DIVBY128              ((uint32)(7u << TIMER_2_PRESCALER_SHIFT))

/* TCPWM set modes */
#define TIMER_2_MODE_TIMER_COMPARE             ((uint32)(TIMER_2__COMPARE         <<  \
                                                                  TIMER_2_MODE_SHIFT))
#define TIMER_2_MODE_TIMER_CAPTURE             ((uint32)(TIMER_2__CAPTURE         <<  \
                                                                  TIMER_2_MODE_SHIFT))
#define TIMER_2_MODE_QUAD                      ((uint32)(TIMER_2__QUAD            <<  \
                                                                  TIMER_2_MODE_SHIFT))
#define TIMER_2_MODE_PWM                       ((uint32)(TIMER_2__PWM             <<  \
                                                                  TIMER_2_MODE_SHIFT))
#define TIMER_2_MODE_PWM_DT                    ((uint32)(TIMER_2__PWM_DT          <<  \
                                                                  TIMER_2_MODE_SHIFT))
#define TIMER_2_MODE_PWM_PR                    ((uint32)(TIMER_2__PWM_PR          <<  \
                                                                  TIMER_2_MODE_SHIFT))

/* Quad Modes */
#define TIMER_2_MODE_X1                        ((uint32)(TIMER_2__X1              <<  \
                                                                  TIMER_2_QUAD_MODE_SHIFT))
#define TIMER_2_MODE_X2                        ((uint32)(TIMER_2__X2              <<  \
                                                                  TIMER_2_QUAD_MODE_SHIFT))
#define TIMER_2_MODE_X4                        ((uint32)(TIMER_2__X4              <<  \
                                                                  TIMER_2_QUAD_MODE_SHIFT))

/* Counter modes */
#define TIMER_2_COUNT_UP                       ((uint32)(TIMER_2__COUNT_UP        <<  \
                                                                  TIMER_2_UPDOWN_SHIFT))
#define TIMER_2_COUNT_DOWN                     ((uint32)(TIMER_2__COUNT_DOWN      <<  \
                                                                  TIMER_2_UPDOWN_SHIFT))
#define TIMER_2_COUNT_UPDOWN0                  ((uint32)(TIMER_2__COUNT_UPDOWN0   <<  \
                                                                  TIMER_2_UPDOWN_SHIFT))
#define TIMER_2_COUNT_UPDOWN1                  ((uint32)(TIMER_2__COUNT_UPDOWN1   <<  \
                                                                  TIMER_2_UPDOWN_SHIFT))

/* PWM output invert */
#define TIMER_2_INVERT_LINE                    ((uint32)(TIMER_2__INVERSE         <<  \
                                                                  TIMER_2_INV_OUT_SHIFT))
#define TIMER_2_INVERT_LINE_N                  ((uint32)(TIMER_2__INVERSE         <<  \
                                                                  TIMER_2_INV_COMPL_OUT_SHIFT))

/* Trigger modes */
#define TIMER_2_TRIG_RISING                    ((uint32)TIMER_2__TRIG_RISING)
#define TIMER_2_TRIG_FALLING                   ((uint32)TIMER_2__TRIG_FALLING)
#define TIMER_2_TRIG_BOTH                      ((uint32)TIMER_2__TRIG_BOTH)
#define TIMER_2_TRIG_LEVEL                     ((uint32)TIMER_2__TRIG_LEVEL)

/* Interrupt mask */
#define TIMER_2_INTR_MASK_TC                   ((uint32)TIMER_2__INTR_MASK_TC)
#define TIMER_2_INTR_MASK_CC_MATCH             ((uint32)TIMER_2__INTR_MASK_CC_MATCH)

/* PWM Output Controls */
#define TIMER_2_CC_MATCH_SET                   (0x00u)
#define TIMER_2_CC_MATCH_CLEAR                 (0x01u)
#define TIMER_2_CC_MATCH_INVERT                (0x02u)
#define TIMER_2_CC_MATCH_NO_CHANGE             (0x03u)
#define TIMER_2_OVERLOW_SET                    (0x00u)
#define TIMER_2_OVERLOW_CLEAR                  (0x04u)
#define TIMER_2_OVERLOW_INVERT                 (0x08u)
#define TIMER_2_OVERLOW_NO_CHANGE              (0x0Cu)
#define TIMER_2_UNDERFLOW_SET                  (0x00u)
#define TIMER_2_UNDERFLOW_CLEAR                (0x10u)
#define TIMER_2_UNDERFLOW_INVERT               (0x20u)
#define TIMER_2_UNDERFLOW_NO_CHANGE            (0x30u)

/* PWM Align */
#define TIMER_2_PWM_MODE_LEFT                  (TIMER_2_CC_MATCH_CLEAR        |   \
                                                         TIMER_2_OVERLOW_SET           |   \
                                                         TIMER_2_UNDERFLOW_NO_CHANGE)
#define TIMER_2_PWM_MODE_RIGHT                 (TIMER_2_CC_MATCH_SET          |   \
                                                         TIMER_2_OVERLOW_NO_CHANGE     |   \
                                                         TIMER_2_UNDERFLOW_CLEAR)
#define TIMER_2_PWM_MODE_ASYM                  (TIMER_2_CC_MATCH_INVERT       |   \
                                                         TIMER_2_OVERLOW_SET           |   \
                                                         TIMER_2_UNDERFLOW_CLEAR)

#if (TIMER_2_CY_TCPWM_V2)
    #if(TIMER_2_CY_TCPWM_4000)
        #define TIMER_2_PWM_MODE_CENTER                (TIMER_2_CC_MATCH_INVERT       |   \
                                                                 TIMER_2_OVERLOW_NO_CHANGE     |   \
                                                                 TIMER_2_UNDERFLOW_CLEAR)
    #else
        #define TIMER_2_PWM_MODE_CENTER                (TIMER_2_CC_MATCH_INVERT       |   \
                                                                 TIMER_2_OVERLOW_SET           |   \
                                                                 TIMER_2_UNDERFLOW_CLEAR)
    #endif /* (TIMER_2_CY_TCPWM_4000) */
#else
    #define TIMER_2_PWM_MODE_CENTER                (TIMER_2_CC_MATCH_INVERT       |   \
                                                             TIMER_2_OVERLOW_NO_CHANGE     |   \
                                                             TIMER_2_UNDERFLOW_CLEAR)
#endif /* (TIMER_2_CY_TCPWM_NEW) */

/* Command operations without condition */
#define TIMER_2_CMD_CAPTURE                    (0u)
#define TIMER_2_CMD_RELOAD                     (8u)
#define TIMER_2_CMD_STOP                       (16u)
#define TIMER_2_CMD_START                      (24u)

/* Status */
#define TIMER_2_STATUS_DOWN                    (1u)
#define TIMER_2_STATUS_RUNNING                 (2u)


/***************************************
*        Function Prototypes
****************************************/

void   TIMER_2_Init(void);
void   TIMER_2_Enable(void);
void   TIMER_2_Start(void);
void   TIMER_2_Stop(void);

void   TIMER_2_SetMode(uint32 mode);
void   TIMER_2_SetCounterMode(uint32 counterMode);
void   TIMER_2_SetPWMMode(uint32 modeMask);
void   TIMER_2_SetQDMode(uint32 qdMode);

void   TIMER_2_SetPrescaler(uint32 prescaler);
void   TIMER_2_TriggerCommand(uint32 mask, uint32 command);
void   TIMER_2_SetOneShot(uint32 oneShotEnable);
uint32 TIMER_2_ReadStatus(void);

void   TIMER_2_SetPWMSyncKill(uint32 syncKillEnable);
void   TIMER_2_SetPWMStopOnKill(uint32 stopOnKillEnable);
void   TIMER_2_SetPWMDeadTime(uint32 deadTime);
void   TIMER_2_SetPWMInvert(uint32 mask);

void   TIMER_2_SetInterruptMode(uint32 interruptMask);
uint32 TIMER_2_GetInterruptSourceMasked(void);
uint32 TIMER_2_GetInterruptSource(void);
void   TIMER_2_ClearInterrupt(uint32 interruptMask);
void   TIMER_2_SetInterrupt(uint32 interruptMask);

void   TIMER_2_WriteCounter(uint32 count);
uint32 TIMER_2_ReadCounter(void);

uint32 TIMER_2_ReadCapture(void);
uint32 TIMER_2_ReadCaptureBuf(void);

void   TIMER_2_WritePeriod(uint32 period);
uint32 TIMER_2_ReadPeriod(void);
void   TIMER_2_WritePeriodBuf(uint32 periodBuf);
uint32 TIMER_2_ReadPeriodBuf(void);

void   TIMER_2_WriteCompare(uint32 compare);
uint32 TIMER_2_ReadCompare(void);
void   TIMER_2_WriteCompareBuf(uint32 compareBuf);
uint32 TIMER_2_ReadCompareBuf(void);

void   TIMER_2_SetPeriodSwap(uint32 swapEnable);
void   TIMER_2_SetCompareSwap(uint32 swapEnable);

void   TIMER_2_SetCaptureMode(uint32 triggerMode);
void   TIMER_2_SetReloadMode(uint32 triggerMode);
void   TIMER_2_SetStartMode(uint32 triggerMode);
void   TIMER_2_SetStopMode(uint32 triggerMode);
void   TIMER_2_SetCountMode(uint32 triggerMode);

void   TIMER_2_SaveConfig(void);
void   TIMER_2_RestoreConfig(void);
void   TIMER_2_Sleep(void);
void   TIMER_2_Wakeup(void);


/***************************************
*             Registers
***************************************/

#define TIMER_2_BLOCK_CONTROL_REG              (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define TIMER_2_BLOCK_CONTROL_PTR              ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TCPWM_CTRL )
#define TIMER_2_COMMAND_REG                    (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define TIMER_2_COMMAND_PTR                    ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TCPWM_CMD )
#define TIMER_2_INTRRUPT_CAUSE_REG             (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define TIMER_2_INTRRUPT_CAUSE_PTR             ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TCPWM_INTR_CAUSE )
#define TIMER_2_CONTROL_REG                    (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__CTRL )
#define TIMER_2_CONTROL_PTR                    ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__CTRL )
#define TIMER_2_STATUS_REG                     (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__STATUS )
#define TIMER_2_STATUS_PTR                     ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__STATUS )
#define TIMER_2_COUNTER_REG                    (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__COUNTER )
#define TIMER_2_COUNTER_PTR                    ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__COUNTER )
#define TIMER_2_COMP_CAP_REG                   (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__CC )
#define TIMER_2_COMP_CAP_PTR                   ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__CC )
#define TIMER_2_COMP_CAP_BUF_REG               (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__CC_BUFF )
#define TIMER_2_COMP_CAP_BUF_PTR               ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__CC_BUFF )
#define TIMER_2_PERIOD_REG                     (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__PERIOD )
#define TIMER_2_PERIOD_PTR                     ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__PERIOD )
#define TIMER_2_PERIOD_BUF_REG                 (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define TIMER_2_PERIOD_BUF_PTR                 ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__PERIOD_BUFF )
#define TIMER_2_TRIG_CONTROL0_REG              (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define TIMER_2_TRIG_CONTROL0_PTR              ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TR_CTRL0 )
#define TIMER_2_TRIG_CONTROL1_REG              (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define TIMER_2_TRIG_CONTROL1_PTR              ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TR_CTRL1 )
#define TIMER_2_TRIG_CONTROL2_REG              (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define TIMER_2_TRIG_CONTROL2_PTR              ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__TR_CTRL2 )
#define TIMER_2_INTERRUPT_REQ_REG              (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__INTR )
#define TIMER_2_INTERRUPT_REQ_PTR              ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__INTR )
#define TIMER_2_INTERRUPT_SET_REG              (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__INTR_SET )
#define TIMER_2_INTERRUPT_SET_PTR              ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__INTR_SET )
#define TIMER_2_INTERRUPT_MASK_REG             (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__INTR_MASK )
#define TIMER_2_INTERRUPT_MASK_PTR             ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__INTR_MASK )
#define TIMER_2_INTERRUPT_MASKED_REG           (*(reg32 *) TIMER_2_cy_m0s8_tcpwm_1__INTR_MASKED )
#define TIMER_2_INTERRUPT_MASKED_PTR           ( (reg32 *) TIMER_2_cy_m0s8_tcpwm_1__INTR_MASKED )


/***************************************
*       Registers Constants
***************************************/

/* Mask */
#define TIMER_2_MASK                           ((uint32)TIMER_2_cy_m0s8_tcpwm_1__TCPWM_CTRL_MASK)

/* Shift constants for control register */
#define TIMER_2_RELOAD_CC_SHIFT                (0u)
#define TIMER_2_RELOAD_PERIOD_SHIFT            (1u)
#define TIMER_2_PWM_SYNC_KILL_SHIFT            (2u)
#define TIMER_2_PWM_STOP_KILL_SHIFT            (3u)
#define TIMER_2_PRESCALER_SHIFT                (8u)
#define TIMER_2_UPDOWN_SHIFT                   (16u)
#define TIMER_2_ONESHOT_SHIFT                  (18u)
#define TIMER_2_QUAD_MODE_SHIFT                (20u)
#define TIMER_2_INV_OUT_SHIFT                  (20u)
#define TIMER_2_INV_COMPL_OUT_SHIFT            (21u)
#define TIMER_2_MODE_SHIFT                     (24u)

/* Mask constants for control register */
#define TIMER_2_RELOAD_CC_MASK                 ((uint32)(TIMER_2_1BIT_MASK        <<  \
                                                                            TIMER_2_RELOAD_CC_SHIFT))
#define TIMER_2_RELOAD_PERIOD_MASK             ((uint32)(TIMER_2_1BIT_MASK        <<  \
                                                                            TIMER_2_RELOAD_PERIOD_SHIFT))
#define TIMER_2_PWM_SYNC_KILL_MASK             ((uint32)(TIMER_2_1BIT_MASK        <<  \
                                                                            TIMER_2_PWM_SYNC_KILL_SHIFT))
#define TIMER_2_PWM_STOP_KILL_MASK             ((uint32)(TIMER_2_1BIT_MASK        <<  \
                                                                            TIMER_2_PWM_STOP_KILL_SHIFT))
#define TIMER_2_PRESCALER_MASK                 ((uint32)(TIMER_2_8BIT_MASK        <<  \
                                                                            TIMER_2_PRESCALER_SHIFT))
#define TIMER_2_UPDOWN_MASK                    ((uint32)(TIMER_2_2BIT_MASK        <<  \
                                                                            TIMER_2_UPDOWN_SHIFT))
#define TIMER_2_ONESHOT_MASK                   ((uint32)(TIMER_2_1BIT_MASK        <<  \
                                                                            TIMER_2_ONESHOT_SHIFT))
#define TIMER_2_QUAD_MODE_MASK                 ((uint32)(TIMER_2_3BIT_MASK        <<  \
                                                                            TIMER_2_QUAD_MODE_SHIFT))
#define TIMER_2_INV_OUT_MASK                   ((uint32)(TIMER_2_2BIT_MASK        <<  \
                                                                            TIMER_2_INV_OUT_SHIFT))
#define TIMER_2_MODE_MASK                      ((uint32)(TIMER_2_3BIT_MASK        <<  \
                                                                            TIMER_2_MODE_SHIFT))

/* Shift constants for trigger control register 1 */
#define TIMER_2_CAPTURE_SHIFT                  (0u)
#define TIMER_2_COUNT_SHIFT                    (2u)
#define TIMER_2_RELOAD_SHIFT                   (4u)
#define TIMER_2_STOP_SHIFT                     (6u)
#define TIMER_2_START_SHIFT                    (8u)

/* Mask constants for trigger control register 1 */
#define TIMER_2_CAPTURE_MASK                   ((uint32)(TIMER_2_2BIT_MASK        <<  \
                                                                  TIMER_2_CAPTURE_SHIFT))
#define TIMER_2_COUNT_MASK                     ((uint32)(TIMER_2_2BIT_MASK        <<  \
                                                                  TIMER_2_COUNT_SHIFT))
#define TIMER_2_RELOAD_MASK                    ((uint32)(TIMER_2_2BIT_MASK        <<  \
                                                                  TIMER_2_RELOAD_SHIFT))
#define TIMER_2_STOP_MASK                      ((uint32)(TIMER_2_2BIT_MASK        <<  \
                                                                  TIMER_2_STOP_SHIFT))
#define TIMER_2_START_MASK                     ((uint32)(TIMER_2_2BIT_MASK        <<  \
                                                                  TIMER_2_START_SHIFT))

/* MASK */
#define TIMER_2_1BIT_MASK                      ((uint32)0x01u)
#define TIMER_2_2BIT_MASK                      ((uint32)0x03u)
#define TIMER_2_3BIT_MASK                      ((uint32)0x07u)
#define TIMER_2_6BIT_MASK                      ((uint32)0x3Fu)
#define TIMER_2_8BIT_MASK                      ((uint32)0xFFu)
#define TIMER_2_16BIT_MASK                     ((uint32)0xFFFFu)

/* Shift constant for status register */
#define TIMER_2_RUNNING_STATUS_SHIFT           (30u)


/***************************************
*    Initial Constants
***************************************/

#define TIMER_2_CTRL_QUAD_BASE_CONFIG                                                          \
        (((uint32)(TIMER_2_QUAD_ENCODING_MODES     << TIMER_2_QUAD_MODE_SHIFT))       |\
         ((uint32)(TIMER_2_CONFIG                  << TIMER_2_MODE_SHIFT)))

#define TIMER_2_CTRL_PWM_BASE_CONFIG                                                           \
        (((uint32)(TIMER_2_PWM_STOP_EVENT          << TIMER_2_PWM_STOP_KILL_SHIFT))   |\
         ((uint32)(TIMER_2_PWM_OUT_INVERT          << TIMER_2_INV_OUT_SHIFT))         |\
         ((uint32)(TIMER_2_PWM_OUT_N_INVERT        << TIMER_2_INV_COMPL_OUT_SHIFT))   |\
         ((uint32)(TIMER_2_PWM_MODE                << TIMER_2_MODE_SHIFT)))

#define TIMER_2_CTRL_PWM_RUN_MODE                                                              \
            ((uint32)(TIMER_2_PWM_RUN_MODE         << TIMER_2_ONESHOT_SHIFT))
            
#define TIMER_2_CTRL_PWM_ALIGN                                                                 \
            ((uint32)(TIMER_2_PWM_ALIGN            << TIMER_2_UPDOWN_SHIFT))

#define TIMER_2_CTRL_PWM_KILL_EVENT                                                            \
             ((uint32)(TIMER_2_PWM_KILL_EVENT      << TIMER_2_PWM_SYNC_KILL_SHIFT))

#define TIMER_2_CTRL_PWM_DEAD_TIME_CYCLE                                                       \
            ((uint32)(TIMER_2_PWM_DEAD_TIME_CYCLE  << TIMER_2_PRESCALER_SHIFT))

#define TIMER_2_CTRL_PWM_PRESCALER                                                             \
            ((uint32)(TIMER_2_PWM_PRESCALER        << TIMER_2_PRESCALER_SHIFT))

#define TIMER_2_CTRL_TIMER_BASE_CONFIG                                                         \
        (((uint32)(TIMER_2_TC_PRESCALER            << TIMER_2_PRESCALER_SHIFT))       |\
         ((uint32)(TIMER_2_TC_COUNTER_MODE         << TIMER_2_UPDOWN_SHIFT))          |\
         ((uint32)(TIMER_2_TC_RUN_MODE             << TIMER_2_ONESHOT_SHIFT))         |\
         ((uint32)(TIMER_2_TC_COMP_CAP_MODE        << TIMER_2_MODE_SHIFT)))
        
#define TIMER_2_QUAD_SIGNALS_MODES                                                             \
        (((uint32)(TIMER_2_QUAD_PHIA_SIGNAL_MODE   << TIMER_2_COUNT_SHIFT))           |\
         ((uint32)(TIMER_2_QUAD_INDEX_SIGNAL_MODE  << TIMER_2_RELOAD_SHIFT))          |\
         ((uint32)(TIMER_2_QUAD_STOP_SIGNAL_MODE   << TIMER_2_STOP_SHIFT))            |\
         ((uint32)(TIMER_2_QUAD_PHIB_SIGNAL_MODE   << TIMER_2_START_SHIFT)))

#define TIMER_2_PWM_SIGNALS_MODES                                                              \
        (((uint32)(TIMER_2_PWM_SWITCH_SIGNAL_MODE  << TIMER_2_CAPTURE_SHIFT))         |\
         ((uint32)(TIMER_2_PWM_COUNT_SIGNAL_MODE   << TIMER_2_COUNT_SHIFT))           |\
         ((uint32)(TIMER_2_PWM_RELOAD_SIGNAL_MODE  << TIMER_2_RELOAD_SHIFT))          |\
         ((uint32)(TIMER_2_PWM_STOP_SIGNAL_MODE    << TIMER_2_STOP_SHIFT))            |\
         ((uint32)(TIMER_2_PWM_START_SIGNAL_MODE   << TIMER_2_START_SHIFT)))

#define TIMER_2_TIMER_SIGNALS_MODES                                                            \
        (((uint32)(TIMER_2_TC_CAPTURE_SIGNAL_MODE  << TIMER_2_CAPTURE_SHIFT))         |\
         ((uint32)(TIMER_2_TC_COUNT_SIGNAL_MODE    << TIMER_2_COUNT_SHIFT))           |\
         ((uint32)(TIMER_2_TC_RELOAD_SIGNAL_MODE   << TIMER_2_RELOAD_SHIFT))          |\
         ((uint32)(TIMER_2_TC_STOP_SIGNAL_MODE     << TIMER_2_STOP_SHIFT))            |\
         ((uint32)(TIMER_2_TC_START_SIGNAL_MODE    << TIMER_2_START_SHIFT)))
        
#define TIMER_2_TIMER_UPDOWN_CNT_USED                                                          \
                ((TIMER_2__COUNT_UPDOWN0 == TIMER_2_TC_COUNTER_MODE)                  ||\
                 (TIMER_2__COUNT_UPDOWN1 == TIMER_2_TC_COUNTER_MODE))

#define TIMER_2_PWM_UPDOWN_CNT_USED                                                            \
                ((TIMER_2__CENTER == TIMER_2_PWM_ALIGN)                               ||\
                 (TIMER_2__ASYMMETRIC == TIMER_2_PWM_ALIGN))               
        
#define TIMER_2_PWM_PR_INIT_VALUE              (1u)
#define TIMER_2_QUAD_PERIOD_INIT_VALUE         (0x8000u)



#endif /* End CY_TCPWM_TIMER_2_H */

/* [] END OF FILE */
