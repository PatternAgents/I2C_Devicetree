/*****************************************************************************
# File Name:	rsvp_cli.c
# Platform :	rsvp
# Version  :	1.10
# Author   :	(www.rsvpsis.com)
#*****************************************************************************
# Copyright:	(C) 2001-2012 by RSVPSIS. All rights reserved.
#*****************************************************************************
# RSVPSIS Licensing Model:
# 
# RSVPSIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 2 (GPLv2), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP software under the GPLv2 license. Please note 
# that GPLv2 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv2 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVPSIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVPSIS commercial licenses 
# expressly supersede the GPLv2 open source license. This means that 
# when you license the RSVPSIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVPSIS Website at : 
#	http://www.rsvpsis.com/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*****************************************************************************
* RSVP Command Line Interface Definitions
******************************************************************************
*
* Description:
* This file describes the set of capabilities provided 
* for RSVP Command Line Interface (rsvp_CLI).
*
*****************************************************************************/
#include <project.h>

#include "rsvp_types.h"
#include "rsvp_conf.h"
#include "rsvp_interrupts.h"
#include "rsvp_platform.h"
#include "rsvp_spwm.h"
#include "rsvp_cli.h"
#include "rsvp_io.h"
#include <stdio.h>
#include <stdlib.h>
#include <string.h>

/*****************************************************************************
* RSVP Command Line Interface Global Variable Defintions
*****************************************************************************/

const tRsVpCmdArray vCommandTable[] = 
{
	{"info",    rsvp_CLI_CmdINFO,		 "    : info - return server information"},
	{"auth",    rsvp_CLI_CmdAUTH,		 "    : auth password - authenticate"},
	{"ping",    rsvp_CLI_CmdPING,		 "    : ping - pong"},
    {"get",	    rsvp_CLI_CmdGET,		 "     : get key - get key value"},	
	{"set",	    rsvp_CLI_CmdSET,		 "     : set key - set key value"},	
	{"command",	rsvp_CLI_CmdCOMMAND,	 " : Show list of CLI Commands"},
	{"console",	rsvp_CLI_CmdConsole,	 " : console X - switch console to channel X"},	
	{"echo",	rsvp_CLI_CmdEcho,		 "    : echo - Echo whatever command line you type (i.e. argv[])"},	
	{"test",	rsvp_CLI_CmdTest,		 "    : test CMD - invoke test command CMD "},	
	{"wire",	rsvp_CLI_CmdWire,		 "    : wire X Y - connect channel X and Y"},	
   {0, 0, 0 }
};
/* variable for number of commands (MAX=255) in command table (in FLASH)    */
rsvp_u8_t bNumCmd = sizeof(vCommandTable)/sizeof(*vCommandTable);

char StrBuf[64] = "                                                      ";
rsvp_u8_t StrBufLen;

rsvp_u8_t rsvp_CLI_Channel = RSVP_CLI_CHANNEL;
rsvp_u8_t rsvp_CLI_NewPrompt = TRUE;
rsvp_u8_t rsvp_CLI_Enable = TRUE;

extern rsvp_RetCode_t  rsvp_KeyHand_FunGPI(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_KeyHand_FunGPO(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_KeyHand_FunADC(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_KeyHand_FunDAC(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_KeyHand_FunTEMP(int argc, char *argv[]);
extern rsvp_RetCode_t  rsvp_KeyHand_FunLED(int argc, char *argv[]);

const tRsVpKeyArray vKeyTable[] = 
{
	{"/gpi",	rsvp_KeyHand_FunGPI,	0, 1, 0xff, "/3200"},	
	{"/gpo",	rsvp_KeyHand_FunGPO,	0, 3, 0xff, "/3201"},	
	{"/adc",	rsvp_KeyHand_FunADC,	0, 4, 0xff, "/3202"},	
	{"/dac",	rsvp_KeyHand_FunDAC,	0, 1, 0xff, "/3203"},	
	{"/temp",	rsvp_KeyHand_FunTEMP,	0, 1, 0xff, "/3303"},	
	{"/led",	rsvp_KeyHand_FunLED,	0, 1, 0xff, "/3311"},	
   {0, 0, 0, 0, 0, 0 }

};
/* variable for number of keys (MAX=255) in command table (in FLASH)    */
rsvp_u8_t bNumKey = sizeof(vKeyTable)/sizeof(*vKeyTable);

/*****************************************************************************
* RSVP Command Line Interface API Defintions
*****************************************************************************/
rsvp_RetCode_t
rsvp_CLI_CmdProcess(char *pcCmdBuffer)
{
    static char *argv[RSVP_CLI_ARGC_MAX + 1];
    char *pcChar;
    int argc;
    int bFoundArgv = 1;
    const tRsVpCmdArray *pCmdEntry;
    rsvp_RetCode_t RetCode;
	
    /* point to the first character of the command line buffer */
    pcChar = pcCmdBuffer;
    /* reset the argument counter */
    argc = 0;
    
    /* loop through the command line buffer until the null terminator is encountered */
    while(*pcChar)
    {
        // If there is a space, then replace it with a zero, and set the flag
        // to search for the next argument.
        if(*pcChar == ' ')
        {
            *pcChar = 0;
            bFoundArgv = 1;
        }

        //
        // Otherwise it is not a space, so it must be a character that is part
        // of an argument.
        //
        else
        {
            //
            // If bFoundArgv is set, then that means we are looking for the start
            // of the next argument.
            //
            if(bFoundArgv)
            {
                //
                // As long as the maximum number of arguments has not been
                // reached, then save the pointer to the start of this new arg
                // in the argv array, and increment the count of args, argc.
                //
                if(argc < RSVP_CLI_ARGC_MAX)
                {
                    argv[argc] = pcChar;
                    argc++;
                    bFoundArgv = 0;
                }

                //
                // The maximum number of arguments has been reached so return
                // the error.
                //
                else
                {
					rsvp_CLI_NewPrompt = TRUE;
                    return(RSVP_ILL_ARG);
                }
            }
        }

        //
        // Advance to the next character in the command line.
        //
        pcChar++;
    }

    //
    // If one or more arguments was found, then process the command.
    //
    if(argc)
    {
        //
        // Start at the beginning of the command table, to look for a matching
        // command.
        //
        pCmdEntry = &vCommandTable[0];

        //
        // Search through the command table until a null command string is
        // found, which marks the end of the table.
        //
        while(pCmdEntry->pcRsVpCmdName)
        {
            //
            // If this command entry command string matches argv[0], then call
            // the function for this command, passing the command line
            // arguments.
            //
            if(!strcmp(argv[0], pCmdEntry->pcRsVpCmdName))
            {
                RetCode = pCmdEntry->pfnRsVpFunction(argc, argv);
				rsvp_CLI_NewPrompt = TRUE;
				return(RetCode);
            }

            //
            // Not found, so advance to the next entry.
            //
            pCmdEntry++;
        }
    }

    //
    // Fall through to here means that no matching command was found, so return
    // an error.
    //
    rsvp_CLI_CmdError(argc, argv);
    return(RSVP_ERR_PLATFORM);
}


/*****************************************************************************
* RSVP Command Line Interface - Command API Defintions
*****************************************************************************/
rsvp_RetCode_t 
rsvp_CLI_CmdCOMMAND(int argc, char *argv[]) {
    (void) (argc);
    (void) (*argv);
	
        /* Count of commands tested */
		rsvp_u8_t cmdcnt;
        
		rsvp_io_PutString(rsvp_CLI_Channel,  " \r");
		for ( cmdcnt = 0; cmdcnt < (bNumCmd-1); cmdcnt++ ) 
		{
    		rsvp_io_PutString(rsvp_CLI_Channel,  (char *) vCommandTable[cmdcnt].pcRsVpCmdName);
            rsvp_io_PutString(rsvp_CLI_Channel,  "    ");
    		rsvp_io_PutString(rsvp_CLI_Channel,  (char *) vCommandTable[cmdcnt].pcRsVpCmdHelp);
			rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
		}	
		return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdError(int argc, char *argv[])
{
    (void) (argc);
    (void) (*argv);
	    /* Unrecognized Command Line Entered */
	    rsvp_io_PutString(rsvp_CLI_Channel,  "\r-ERROR Unknown COMMAND\r\n>");
		return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdConsole(int argc, char *argv[])
{
	rsvp_u8_t  Console_ChanNum = 1;

    if (argc > 1 ) {
	   Console_ChanNum = (rsvp_u8_t) atoi(argv[1]);
	}
	if (Console_ChanNum == 0) {
       rsvp_CLI_NewPrompt = FALSE;
       rsvp_CLI_Enable = FALSE;
	   Console_ChanNum = 1;
	} else if (Console_ChanNum == 255) {
       rsvp_CLI_NewPrompt = FALSE;
       rsvp_CLI_Enable = FALSE;
	   Console_ChanNum = 1;
	} else if (Console_ChanNum > 2) {
	  Console_ChanNum = 1;
	}
    ENTER_CRITICAL_SECTION( );
	rsvp_CLI_Channel = Console_ChanNum;
    EXIT_CRITICAL_SECTION( );
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdEcho(int argc, char *argv[])
{
	rsvp_u8_t i;

	rsvp_io_PutString(rsvp_CLI_Channel,  " \r");
	for (i = 1; i < argc; i++)
	{
		rsvp_io_PutString(rsvp_CLI_Channel,  argv[i]);
		rsvp_io_PutString(rsvp_CLI_Channel,  " ");
	}
	rsvp_io_PutString(rsvp_CLI_Channel,  " \r\n");
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdSpwmPeriod(int argc, char *argv[])
{
    (void) (argc);

    rsvp_u32_t  SPWM_Period;
    SPWM_Period = atol(argv[1]);
    RSVP_SPWM_PeriodSet(SPWM_Period);
    return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdSpwmChannel(int argc, char *argv[])
{
    rsvp_u8_t  SPWM_ChanNum = 0;
    rsvp_u8_t  SPWM_ChanEnable = 0;
    rsvp_u8_t  SPWM_ChanMask = 0;
    rsvp_u32_t SPWM_ChanStart = 0;
    rsvp_u32_t SPWM_ChanEnd = 0;
	int tmp = 0;
	char str_tmp_Buffer[10] = "        ";

	/* Test Argc (number of arguments) */
    if (argc < 3) {
		return(RSVP_ILL_ARG);
	}

	SPWM_ChanNum = (rsvp_u8_t) atoi(argv[1]);
	SPWM_ChanMask = RSVP_SPWM_ChanEnableGet();
    if ((argc == 3) && (strcmp( "?", argv[2] ) == 0)) {
		
		SPWM_ChanStart = RSVP_SPWM_StartGet(SPWM_ChanNum-1);
		SPWM_ChanEnd =   RSVP_SPWM_EndGet(SPWM_ChanNum-1);

		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nSPWM Channel = ");
		rsvp_io_PutString(rsvp_CLI_Channel,  argv[1]);
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nSWPM Mask = ");
		tmp = (int) SPWM_ChanMask;
		rsvp_CLI_itoa(str_tmp_Buffer, tmp, 10); 
		rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nSPWM Start = ");
		tmp = (int) SPWM_ChanStart;
		rsvp_CLI_itoa(str_tmp_Buffer, tmp, 10); 
		rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nSPWM End = ");
		tmp = (int) SPWM_ChanEnd;
		rsvp_CLI_itoa(str_tmp_Buffer, tmp, 10); 
		rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n\r\n");
		return(RSVP_SUCCESS);
    }

	SPWM_ChanEnable = (rsvp_u8_t) atoi(argv[2]);
	
	if (SPWM_ChanEnable != 0)
	{
		SPWM_ChanMask |= (1 << (SPWM_ChanNum-1));
	} 

	SPWM_ChanStart = atol(argv[3]);
    SPWM_ChanEnd = atol(argv[4]);
	RSVP_SPWM_StartSet((SPWM_ChanNum-1), SPWM_ChanStart);
	RSVP_SPWM_EndSet((SPWM_ChanNum-1), SPWM_ChanEnd);
    RSVP_SPWM_ChanEnableSet(SPWM_ChanMask);

	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdADCChannel(int argc, char *argv[])
{
    rsvp_u8_t  ADC_ChanNum = 0;
	int tmp = 0;
	char str_tmp_Buffer[10] = "        ";

	/* Test Argc (number of arguments) */
    if (argc < 3) {
		return(RSVP_ILL_ARG);
	}

	ADC_ChanNum = (rsvp_u8_t) atoi(argv[2]);
    if ((argc == 3) && (strcmp( "?", argv[2] ) == 0)) {	
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\nADC Channel = ");
		rsvp_io_PutString(rsvp_CLI_Channel,  argv[1]);
		rsvp_io_PutString(rsvp_CLI_Channel,  ",  ADC Data = ");
		tmp = (int) adc_1_data[ADC_ChanNum];
		rsvp_CLI_itoa(str_tmp_Buffer, tmp, 10); 
		rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n\r\n");
    }
	return(RSVP_SUCCESS);
}



char* rsvp_CLI_itoa(char* result, int value, int base) 
{
		/* test if the base parameter is valid */
		if (base < 2 || base > 36) { *result = '\0'; return result; }
	
		char* ptr = result, *ptr1 = result, tmp_char;
		int tmp_value;
	
		do {
			tmp_value = value;
			value /= base;
			*ptr++ = "zyxwvutsrqponmlkjihgfedcba9876543210123456789abcdefghijklmnopqrstuvwxyz" [35 + (tmp_value - value * base)];
		} while ( value );
	
		/* insert negative sign if applicable */
		if (tmp_value < 0) *ptr++ = '-';
		*ptr-- = '\0';
		while(ptr1 < ptr) {
			tmp_char = *ptr;
			*ptr--= *ptr1;
			*ptr1++ = tmp_char;
		}
		return result;
}

rsvp_RetCode_t
rsvp_CLI_CmdWire(int argc, char *argv[])
{
    rsvp_u8_t X, Y, X_len, Y_len, X_buf, Y_buf;
    rsvp_u8_t wire_break = 1;
    
    if (argc > 2 ) {
	  X = (rsvp_u8_t) atoi(argv[1]);
	  Y = (rsvp_u8_t) atoi(argv[2]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n Wiring Channel ");
	  rsvp_io_PutString(rsvp_CLI_Channel,  argv[1]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  " to Channel  ");
	  rsvp_io_PutString(rsvp_CLI_Channel,  argv[2]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  " : Break to Escape\r\n");
    
      /* wire the channels until a break is detected */
      while (wire_break != 0) {
          X_len = rsvp_io_GetRxBufferSize(X);
          if (X_len != 0) {
              X_buf = rsvp_io_GetChar(X);
              rsvp_io_PutChar(Y, X_buf);
          }
          Y_len = rsvp_io_GetRxBufferSize(Y);
          if (Y_len != 0) {
              Y_buf = rsvp_io_GetChar(Y);
              rsvp_io_PutChar(X, Y_buf);
          }
          wire_break = USER_SW_1_Read();
      }
	}
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdTest(int argc, char *argv[])
{
	rsvp_u16_t  channum, chandata;
	char str_tmp_Buffer[10] = "        ";

	if (argc > 1 ) {
	if ((strcmp( "adc", argv[1] ) == 0)) {
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n");
	  for (channum = 0; channum < ADC_1_TOTAL_CHANNELS_NUM; channum++){
		rsvp_CLI_itoa(str_tmp_Buffer, channum, 10); 
		rsvp_io_PutString(rsvp_CLI_Channel,  "ADC Channel = ");
		rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		rsvp_io_PutString(rsvp_CLI_Channel,  ",  ADC Data = ");
		chandata = (int) adc_1_data[channum];
		rsvp_CLI_itoa(str_tmp_Buffer, chandata, 10); 
		rsvp_io_PutString(rsvp_CLI_Channel,  str_tmp_Buffer);
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n");
	  }
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n");
	} else if ((strcmp( "led", argv[1] ) == 0)) { 
	  rsvp_io_PutString(rsvp_CLI_Channel, "\r\n test led : running LED blink sequence");	
      CyDelay(200);
	  rsvp_io_PutLog(0x00, (char *) rsvp_io_LEDblink, 16);	
    } else if ((strcmp( "self", argv[1] ) == 0)) {
		/* stubbed for space - restore full self test code here */
		rsvp_io_PutString(rsvp_CLI_Channel, "test self : self test by/passed \r\n\r\n");
        CyDelay(200);
    } else if ((strcmp( "uart", argv[1] ) == 0)) {		/* stubbed for space - restore full self test code here */
		rsvp_io_PutString(1, "uart channel #1 : 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ \r\n\r\n");
		rsvp_io_PutString(2, "uart channel #2 : 0123456789ABCDEFGHIJKLMNOPQRSTUVWXYZ \r\n\r\n");
        CyDelay(200);
	} else if ((strcmp( "boot", argv[1] ) == 0)) {
		rsvp_io_PutString(rsvp_CLI_Channel, "\r\n boot loader : entering the boot loader program for firmware update!");	
		rsvp_io_PutString(rsvp_CLI_Channel, "\r\n boot loader : (exit the terminal app and start the Bootloader Host app!) \r\n\r\n");	
        CyDelay(200);
        #if !defined BOOTLD_PG__DISABLED
          Bootloadable_Load();
        #endif
	} else if ((strcmp( "spwm", argv[1] ) == 0)) {
		/* stubbed for space - restore full spwm test code here */
		rsvp_io_PutString(rsvp_CLI_Channel, "test spwm : software pwm test by/passed \r\n\r\n");
        CyDelay(200);
	}
    }
	return(RSVP_SUCCESS);
}

void rsvp_CLI_Poll(void) 
{
  rsvp_u8_t StringLen;
	
  #if (RSVP_USE_CLI == TRUE)
	if (rsvp_CLI_Enable == TRUE) {
      /* send the command line prompt */
	  if (rsvp_CLI_NewPrompt == TRUE ) {
        rsvp_io_PutString(rsvp_CLI_Channel, "> ");
	    rsvp_CLI_NewPrompt = FALSE;
	  }
     
      /* Don't block unless some characters are entered ... */
      StringLen = rsvp_io_GetRxBufferSize(rsvp_CLI_Channel);
      if (StringLen != 0 ) {
          /* Block until a command is entered and returned */
          StringLen = rsvp_io_GetString(rsvp_CLI_Channel, &StrBuf[0], 64);
      }
	
      /* Pass the line to the Command Line Interpreter */
      /* if there more than a zero length - i.e. more than a delimiter? */
      if( StringLen != 0 ) 
	  {
		/* parse and execute the command line */
        rsvp_CLI_CmdProcess(&StrBuf[0]);
	  }
	}
  #endif
}

rsvp_RetCode_t 
rsvp_CLI_CmdINFO(int argc, char *argv[]) {
    (void) (argc);
    (void) (*argv);
	        
		rsvp_io_PutString(rsvp_CLI_Channel,  "\r#Server\r\n");
		rsvp_io_PutString(rsvp_CLI_Channel,  "redis_version:x.1.0\r\n");        
		rsvp_io_PutString(rsvp_CLI_Channel,  "redis_mode:standalone\r\n");        
		rsvp_io_PutString(rsvp_CLI_Channel,  "tcp_port:6379\r\n");        
		return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdGET(int argc, char *argv[])
{
    (void) argv;

	if (argc > 1 ) {
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r+");
      rsvp_io_PutString(rsvp_CLI_Channel,  argv[1]);
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r\n");
	}
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdSET(int argc, char *argv[])
{
    (void) argv;

	if (argc > 1 ) {
	  rsvp_io_PutString(rsvp_CLI_Channel,  "\r+OK\r\n");
	}
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdPING(int argc, char *argv[])
{
    (void) argc;
    (void) argv;
	rsvp_io_PutString(rsvp_CLI_Channel,  "\r+PONG\r\n");
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_CLI_CmdAUTH(int argc, char *argv[])
{
    (void) argv;

    if (argc == 2 ) {
        if ((strcmp( "password", argv[1] ) == 0)) {
	      rsvp_io_PutString(rsvp_CLI_Channel,  "\r+OK\r\n");
        } else {
	      rsvp_io_PutString(rsvp_CLI_Channel,  "\r-ERR Authentication Failure\r\n");
        }
	} else {
	      rsvp_io_PutString(rsvp_CLI_Channel,  "\r-ERR Authentication Failure\r\n");
    }
	return(RSVP_SUCCESS);
}


rsvp_RetCode_t
rsvp_KeyHand_FunGPI(int argc, char *argv[])
{
    (void) argv;
    (void) argc;
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_KeyHand_FunGPO(int argc, char *argv[])
{
    (void) argv;
    (void) argc;
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_KeyHand_FunADC(int argc, char *argv[])
{
    (void) argv;
    (void) argc;
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_KeyHand_FunDAC(int argc, char *argv[])
{
    (void) argv;
    (void) argc;
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_KeyHand_FunTEMP(int argc, char *argv[])
{
    (void) argv;
    (void) argc;
	return(RSVP_SUCCESS);
}

rsvp_RetCode_t
rsvp_KeyHand_FunLED(int argc, char *argv[])
{
    (void) argv;
    (void) argc;
	return(RSVP_SUCCESS);
}

/****************************************************************************/
/* End of File : rsvp_cli.c */
