/*****************************************************************************
# File Name:	rsvp_spwm.c
# Platform :	rsvp
# Version  :	1.10
# Author   :	(www.rsvpsis.com)
#*****************************************************************************
# Copyright:	(C) 2001-2012 by RSVPSIS. All rights reserved.
#*****************************************************************************
# RSVPSIS Licensing Model:
# 
# RSVPSIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 2 (GPLv2), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP software under the GPLv2 license. Please note 
# that GPLv2 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv2 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVPSIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVPSIS commercial licenses 
# expressly supersede the GPLv2 open source license. This means that 
# when you license the RSVPSIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVPSIS Website at : 
#	http://www.rsvpsis.com/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*****************************************************************************
* Software PWM (SPWM) Definitions
******************************************************************************
*
* Description:
* This file describes the set of capabilities provided 
* for Software PWM (SPWM).
*
*****************************************************************************/
#include <project.h>
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <rsvp_cli.h>
#include <rsvp_spwm.h>
#include <rsvp_adc.h>

#if defined(RSVP_USE_SPWM_1)
#include "SPWM_1.h"

/*****************************************************************************
* Global Variable Defintions
*****************************************************************************/

/* Global RSVP PWM Load Enable Flag - Enable = "1" */
rsvp_u8_t RSVP_SPWM_LoadEnable = 0;
/* Global RSVP PWM Current Enable Flag - Enable = "1" */
rsvp_u8_t RSVP_SPWM_CurrEnable = 0;
/* Software PWM Tick Counter */
rsvp_u32_t  RSVP_SPWM_Count = 0;
/* Software PWM Reload Period Default 1000 counts = 1 sec */
rsvp_u32_t  RSVP_SPWM_LoadPeriod = 1000;
/* Software PWM Period Default 1000 counts = 1 sec */
rsvp_u32_t  RSVP_SPWM_CurrPeriod = 1000;
/* variable for number of SoftPWM Channel (MAX=8 (8 bits)) */
rsvp_u32_t RSVP_SPWM_LoadStart[RSVP_SPWM_NumChans] = { 0, 0, 0, 0, 0, 0, 0, 999 };
/* SPWM End Count Reload Value Holding Array */
rsvp_u32_t RSVP_SPWM_LoadEnd[RSVP_SPWM_NumChans]   = { 500, 500, 500, 500, 500, 500, 500, 999 };
/* SPWM Current Pulse Start Count Value Holding Array		*/
rsvp_u32_t RSVP_SPWM_PulseStart[RSVP_SPWM_NumChans] = { 0 };
/* SPWM Current Pulse End Count Value Holding Array		*/
rsvp_u32_t RSVP_SPWM_PulseEnd[RSVP_SPWM_NumChans] = { 0 };
/* enable bitmask - one bit per channel - Enable = "1" */
rsvp_u8_t RSVP_SPWM_LoadChanEnable = 0x00 ;
/* enable bitmask - one bit per channel - Enable = "1" */
rsvp_u8_t RSVP_SPWM_CurrChanEnable = 0x00 ;
/* shadow of the current SPWM State */
rsvp_u8_t RSVP_SPWM_CurrState = 0x00 ;
/* RSVP SPWM Loop Counter */
rsvp_u8_t RSVP_SPWM_PeriodCnt = 0;

/* RSVP SPWM Loop Counter */
rsvp_u8_t RSVP_SPWM_PeriodCount = 0;
/* RSVP PWM Current Enable Flag - Enable = "1" */
rsvp_u8_t RSVP_SPWM_Enabled = 0;
/* RSVP PWM Current Output State */
rsvp_u8_t RSVP_SPWM_State = 0;

/* RSVP PWM Current Output State */
rsvp_u8_t RSVP_SPWM_ChanCnt = 0;

/*****************************************************************************
* SPWM API Defintions
*****************************************************************************/

void RSVP_SPWM_Initialize(void) 
{
    rsvp_u8_t chan_cnt = 0;

    /* set the PWM counter to zero */
    RSVP_SPWM_Count = 0;

    /* only change the global enable during re/initialize */
    RSVP_SPWM_CurrEnable = RSVP_SPWM_LoadEnable;
    
    /* only change the channel enables during re/initialize */
    RSVP_SPWM_CurrChanEnable = RSVP_SPWM_LoadChanEnable;
    
    /* only change the period during re/initialize */
    RSVP_SPWM_CurrPeriod = RSVP_SPWM_LoadPeriod;
    
    /* set all output values to zero */
    RSVP_SPWM_CurrState = 0;
    
    /* reload all the channel compare registers */
    for (chan_cnt = 0; chan_cnt < RSVP_SPWM_NumChans; chan_cnt++) {
        RSVP_SPWM_PulseStart[chan_cnt] = RSVP_SPWM_LoadStart[chan_cnt];
        RSVP_SPWM_PulseEnd[chan_cnt] = RSVP_SPWM_LoadEnd[chan_cnt];
    }
}

void RSVP_SPWM_Update(void) 
{
    rsvp_u8_t chan_cnt = 0;
    rsvp_u8_t chan_mask = 0;

    /* update the SWPM Channels */
    if (RSVP_SPWM_Count <= RSVP_SPWM_CurrPeriod) {
        for (chan_cnt = 0; chan_cnt < RSVP_SPWM_NumChans; chan_cnt++) {
            chan_mask = (RSVP_SPWM_CurrChanEnable & (0x01 << chan_cnt));
            /* if the channel is enabled , process it */
            if (chan_mask != 0) {
                /* test the channel for a Start or End compare match */ 
                if ((RSVP_SPWM_PulseStart[chan_cnt] == RSVP_SPWM_Count) || 
                    (RSVP_SPWM_PulseEnd[chan_cnt] == RSVP_SPWM_Count)) {
                    /* Invert the output value */
                    RSVP_SPWM_CurrState ^= chan_mask;
                }
            }
        }
    } else {
        /* if the period count has expired, then re-Initialize, increment the period counter */
        RSVP_SPWM_Initialize();
        RSVP_SPWM_PeriodCnt++;
    }
    /* increment the SPWM counter */
    RSVP_SPWM_Count++;
}

/* RSVP SPWM API Routines */
void RSVP_SPWM_Enable(void)
{
    RSVP_SPWM_LoadEnable = 1;
    RSVP_SPWM_Initialize();
}

void RSVP_SPWM_Disable(void)
{
    RSVP_SPWM_LoadEnable = 0;
}

rsvp_u8_t RSVP_SPWM_EnableGet(void)
{
    return(RSVP_SPWM_CurrEnable);
}

void RSVP_SPWM_PeriodSet(rsvp_u32_t Period)
{
    RSVP_SPWM_LoadPeriod = Period;
}

rsvp_u32_t RSVP_SPWM_PeriodGet(void)
{
    return(RSVP_SPWM_LoadPeriod);
}

rsvp_u32_t RSVP_SPWM_PeriodCountGet(void)
{
    return(RSVP_SPWM_PeriodCnt);
}

void RSVP_SPWM_PeriodCountSet(rsvp_u32_t Period)
{
    RSVP_SPWM_PeriodCnt = Period;
}

rsvp_u32_t RSVP_SPWM_CountGet(void)
{
    return(RSVP_SPWM_Count);
}

rsvp_u8_t RSVP_SPWM_StateGet(void)
{
    return(RSVP_SPWM_CurrState);
}

void RSVP_SPWM_ChanEnableSet(rsvp_u8_t ChanMask)
{
    RSVP_SPWM_LoadChanEnable = ChanMask;
}

rsvp_u8_t RSVP_SPWM_ChanEnableGet(void)
{
    return(RSVP_SPWM_LoadChanEnable);
}

void RSVP_SPWM_StartSet(rsvp_u8_t channel, rsvp_u32_t StartTick)
{
    RSVP_SPWM_LoadStart[channel] = StartTick;
}
rsvp_u32_t RSVP_SPWM_StartGet(rsvp_u8_t channel)
{
    return(RSVP_SPWM_LoadStart[channel]);
}

void RSVP_SPWM_EndSet(rsvp_u8_t channel, rsvp_u32_t StartTick)
{
    RSVP_SPWM_LoadEnd[channel] = StartTick;
}

rsvp_u32_t RSVP_SPWM_EndGet(rsvp_u8_t channel)
{
    return(RSVP_SPWM_LoadEnd[channel]);
}

#endif
/* End of File : rsvp_spwm.c */
