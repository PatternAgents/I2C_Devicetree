/*****************************************************************************
# File Name:	rsvp_spwm.h
# Platform :	rsvp
# Version  :	1.10
# Author   :	(www.rsvpsis.com)
#*****************************************************************************
# Copyright:	(C) 2001-2012 by RSVPSIS. All rights reserved.
#*****************************************************************************
# RSVPSIS Licensing Model:
# 
# RSVPSIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 2 (GPLv2), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP software under the GPLv2 license. Please note 
# that GPLv2 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv2 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVPSIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVPSIS commercial licenses 
# expressly supersede the GPLv2 open source license. This means that 
# when you license the RSVPSIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVPSIS Website at : 
#	http://www.rsvpsis.com/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
*****************************************************************************/

/*****************************************************************************
* Software PWM Definitions
******************************************************************************
*
* Description:
* This file describes the set of capabilities provided 
* for Software PWM (SPWM).
*
*****************************************************************************/

/*--------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                    */
/*--------------------------------------------------------------------------*/
#ifndef __RSVP_SPWM_H__
#define __RSVP_SPWM_H__

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

#include <rsvp_types.h>

/*--------------------------------------------------------------------------*/
/* Software PWM (SPWM) Defines                                              */
/*--------------------------------------------------------------------------*/
/* RSVP Number of Channels (MAX = 8)                                        */
#define RSVP_SPWM_NumChans			8

/* RSVP SPWM Loop Counter */
extern rsvp_u8_t RSVP_SPWM_PeriodCount;
/* RSVP PWM Current Enable Flag - Enable = "1" */
extern rsvp_u8_t RSVP_SPWM_Enabled;
/* RSVP PWM Current Output State */
extern rsvp_u8_t RSVP_SPWM_State;

/*--------------------------------------------------------------------------*/
/* Software PWM (SPWM) API Functions                                        */
/*--------------------------------------------------------------------------*/
extern void         RSVP_SPWM_Initialize(void);
extern void         RSVP_SPWM_Enable(void);
extern rsvp_u8_t    RSVP_SPWM_EnableGet(void);
extern void         RSVP_SPWM_Disable(void);
extern void			RSVP_SPWM_PeriodSet(rsvp_u32_t Period);
extern rsvp_u32_t	RSVP_SPWM_PeriodGet(void);
extern rsvp_u32_t	RSVP_SPWM_PeriodCountGet(void);
extern void			RSVP_SPWM_PeriodCountSet(rsvp_u32_t Period);
extern rsvp_u32_t	RSVP_SPWM_CountGet(void);
extern rsvp_u8_t	RSVP_SPWM_StateGet(void);
extern void			RSVP_SPWM_ChanEnableSet(rsvp_u8_t ChanMask);
extern rsvp_u8_t	RSVP_SPWM_ChanEnableGet(void);
extern void			RSVP_SPWM_StartSet(rsvp_u8_t channel, rsvp_u32_t StartTick);
extern rsvp_u32_t	RSVP_SPWM_StartGet(rsvp_u8_t channel);
extern void			RSVP_SPWM_EndSet(rsvp_u8_t channel, rsvp_u32_t StartTick);
extern rsvp_u32_t	RSVP_SPWM_EndGet(rsvp_u8_t channel);
extern void			RSVP_SPWM_Update( void );

/*--------------------------------------------------------------------------*/
#ifdef __cplusplus
} 
#endif /* __cplusplus */

#endif /* __RSVP_SPWM_H__ */
/* End of File : RSVP_SPWM.h */

