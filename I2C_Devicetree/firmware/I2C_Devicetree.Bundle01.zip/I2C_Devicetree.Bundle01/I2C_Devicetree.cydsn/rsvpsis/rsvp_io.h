/**
  ******************************************************************************
  *
  * @file        rsvp_io.h
  * @author      Moxon Design
  * @version     0.0.1
  * @date        2013-06-27
  * @copyright   Moxon Design
  * @brief       The include file to define all the Analog-to-Digital Converter routines
  *
  ******************************************************************************
  */

/*-----------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                       */
/*-----------------------------------------------------------------------------*/
#ifndef RSVP_IO_H_
#define RSVP_IO_H_

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */
	
/*-----------------------------------------------------------------------------*/
/* Include Files                                                               */
/*-----------------------------------------------------------------------------*/
#include <project.h>
#include <rsvp_types.h>
#include <rsvp_conf.h>
#include <rsvp_interrupts.h>
#include <rsvp_platform.h>
#include <CyLib.h>
#include <cydevice_trm.h>

/** @addtogroup rsvp_io_ rsvp_io_
  * @{
  */

/*-----------------------------------------------------------------------------*/
/* Exported Types                                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_io_Exported_Types
  * @{
  */

/**
  * Close the Doxygen rsvp_io__Exported_Types group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Constants                                                          */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_io_Exported_Constants
  * @{
  */

/**
  * Close the Doxygen rsvp_io_Exported_Constants group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Macros                                                             */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_io_Exported_Macros
  * @{
  */

/**
  * Close the Doxygen rsvp_io_Exported_Macros group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Variable Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_io_Exported_Variables
  * @{
  */
extern rsvp_cu8_t rsvp_io_LEDblink[16];

/**
  * Close the Doxygen rsvp_io_Exported_Variables group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* Exported Function Declarations                                              */
/*-----------------------------------------------------------------------------*/
/** @defgroup rsvp_io_Exported_Functions
  * @{
  */
extern rsvp_u8_t      rsvp_io_GetString(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen);
extern rsvp_RetCode_t rsvp_io_PutString(rsvp_u8_t channel, char *Buffer);
extern rsvp_RetCode_t rsvp_io_PutChar(rsvp_u8_t channel, rsvp_u8_t Buffer);
extern rsvp_u8_t      rsvp_io_GetChar(rsvp_u8_t channel);
extern rsvp_u32_t     rsvp_io_GetRxBufferSize(rsvp_u8_t channel);

extern rsvp_RetCode_t rsvp_io_PutLog(rsvp_u8_t channel, char *Buffer, rsvp_u8_t BufLen);

/**
  * Close the Doxygen rsvp_io_Exported_Functions group.
  * @}
  */

/*-----------------------------------------------------------------------------*/
/* End of the C bindings section for C++ compilers.                            */
/*-----------------------------------------------------------------------------*/
#ifdef __cplusplus
}
#endif

#endif /* RSVP_IO_H_ */

/*-----------------------------------------------------------------------------*/
/**
  * Close the Doxygen rsvp_io_ group.
  *    @}
*/

