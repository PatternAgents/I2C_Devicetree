/*****************************************************************************
# File Name:	rsvp_types.h
# Platform :	rsvp
# Version  :	1.10
# Author   :	(www.rsvpsis.com)
#*****************************************************************************
# Copyright:	(C) 2001-2015 by PatternAgents,LLC. All rights reserved.
#*****************************************************************************
# RSVPSIS Licensing Model:
# 
# RSVPSIS uses the increasingly popular business model called 
# "Dual Licensing" in which both the open source software distribution 
# mechanism and traditional commercial software distribution models 
# are combined.
# 
# Open Source Projects:
# 
# If you are developing and distributing open source applications 
# under the GNU General Public License version 2 (GPLv2), 
# as published by the Free Software Foundation, then you are free 
# to use the RSVP software under the GPLv2 license. Please note 
# that GPLv2 Section 2(b) requires that all modifications to the 
# original code as well as all Derivative Works must also be 
# released under the terms of the GPLv2 open source license.
# 
# Closed Source Projects:
# 
# If you are developing and distributing traditional closed source 
# applications, you must purchase a RSVPSIS commercial use license, 
# which is specifically designed for users interested in retaining 
# the proprietary status of their code. All RSVPSIS commercial licenses 
# expressly supersede the GPLv2 open source license. This means that 
# when you license the RSVPSIS software under a commercial license, 
# you specifically do not use the software under the open source 
# license and therefore you are not subject to any of its terms.
#
# Commercial licensing options available on the RSVPSIS Website at : 
#	http://www.rsvpsis.com/licensing/
#
#*****************************************************************************
# THIS SOFTWARE IS PROVIDED BY THE COPYRIGHT HOLDERS AND CONTRIBUTORS 
# "AS IS" AND ANY EXPRESS OR IMPLIED WARRANTIES, INCLUDING, 
# BUT NOT LIMITED TO, THE IMPLIED WARRANTIES OF MERCHANTABILITY AND FITNESS 
# FOR A PARTICULAR PURPOSE ARE DISCLAIMED. IN NO EVENT SHALL THE 
# COPYRIGHT OWNER OR CONTRIBUTORS BE LIABLE FOR ANY DIRECT, INDIRECT, 
# INCIDENTAL, SPECIAL, EXEMPLARY, OR CONSEQUENTIAL DAMAGES 
# (INCLUDING, BUT NOT LIMITED TO, PROCUREMENT OF SUBSTITUTE GOODS OR SERVICES; 
# LOSS OF USE, DATA, OR PROFITS; OR BUSINESS INTERRUPTION) HOWEVER CAUSED 
# AND ON ANY THEORY OF LIABILITY, WHETHER IN CONTRACT, STRICT LIABILITY, 
# OR TORT (INCLUDING NEGLIGENCE OR OTHERWISE) ARISING IN ANY WAY OUT OF THE 
# USE OF THIS SOFTWARE, EVEN IF ADVISED OF THE POSSIBILITY OF SUCH DAMAGE.
#*****************************************************************************
#
# Introduction:
#
# The Reference System Virtual Platform, System Interface Standard (RSVPSIS) 
# project is used to specify the basic parameters and interfaces 
# available on different classes of System-on-Chip (SoC),
# Application Specific Integrated Circuits (ASIC), and
# Application Specific System Platforms (ASSP).
#   
# The RSVPSIS is used to make the job of porting 
# application software, RTOS/BIOS systems,
# and the associated Board Support Packages (BSP)
# for different product combinations in use today,
# a much easier task.
#
*****************************************************************************/

/*****************************************************************************
# Platform Exported Type Definitions
#*****************************************************************************
#
# Description:
#
# Different Compilers can handle data types very differently,
# especially when you start talking about possible cached types,
# volatile/hardware register types, flash memory location types,
# and other interesting behaviors. This include file is intended
# to give the user some consistancy (where possible) across
# compiler and architecture variations by appropriate type definition.
# The idea is reduce the amount of ifdef-ed code in your main routines.
#
#*****************************************************************************
# Compiler Model Definitions :
# 
#	__IMAGECRAFT__		ImageCraft "C" Compiler		[M8C]            (PSoC1)
#	  HI_TECH_C			Hi-Tech "C Compiler			[M8C]            (PSoC1)
#	__C51__				Keil i8051 "C" Compiler		[i8051]          (PSoC3)
#	__CX51__			Keil i8051 "C" Compiler		[i8051]          (PSoC3)
#	__GNUC__			GNU "C" Compiler			[ARM Cortex M]   (PSoC5)
#	__CC_ARM			ARM Realview Compiler		[ARM Cortex M]   (PSOC5)
#
# Not Yet Supported (To Do List) :
#	__TASKING__			Tasking Compiler
#	__ICCARM__			IAR Compiler
#			
*****************************************************************************/

/*--------------------------------------------------------------------------*/
/* Define to prevent recursive inclusion                                    */
/*--------------------------------------------------------------------------*/
#ifndef __RSVP_TYPES_H__
#define __RSVP_TYPES_H__

/* Define to support C++ */
#ifdef __cplusplus
extern "C" {
#endif /* __cplusplus */

/****************************************************************************/
/* Types are designed to conform to MISRA C guidelines for specifying       */
/* both signedness and size, but also include volatile and const/flash      */
/****************************************************************************/
/* Type Definitions that are common to all the Compilers                    */
/****************************************************************************/
#if    defined(__IMAGECRAFT__)  \
	|| defined(HI_TECH_C)       \
	|| defined(__C51__)         \
	|| defined(__CX51__)        \
	|| defined(__CC_ARM)        \
	|| defined(__GNUC__) 

/* Basic unsigned types                                                     */
typedef unsigned char						rsvp_u8_t;
typedef unsigned short						rsvp_u16_t;
typedef unsigned long						rsvp_u32_t;

/* Basic signed types                                                       */
typedef signed char							rsvp_s8_t;
typedef signed short						rsvp_s16_t;
typedef int         						rsvp_i16_t;
typedef signed long							rsvp_s32_t;

/* Basic volatile unsigned types - signal compiler don't cache these types  */
typedef unsigned char volatile 				rsvp_vu8_t;
typedef unsigned short volatile				rsvp_vu16_t;
typedef unsigned long volatile				rsvp_vu32_t;

/* Basic volatile signed types - signal compiler don't cache these types    */
typedef signed char volatile 				rsvp_vs8_t;
typedef signed short volatile				rsvp_vs16_t;
typedef signed long volatile				rsvp_vs32_t;

/* Basic constant unsigned types                                            */
typedef unsigned char const					rsvp_cu8_t;        /* Read Only */
typedef unsigned short const				rsvp_cu16_t;       /* Read Only */
typedef unsigned long const					rsvp_cu32_t;       /* Read Only */

/* Basic constant signed types                                              */
typedef signed char const					rsvp_cs8_t;        /* Read Only */
typedef signed short const					rsvp_cs16_t;       /* Read Only */
typedef signed long const					rsvp_cs32_t;       /* Read Only */

/* Volatile constant unsigned types signal compiler don't cache these types */
typedef unsigned char volatile const		rsvp_vcu8_t;       /* Read Only */
typedef unsigned short volatile const		rsvp_vcu16_t;      /* Read Only */
typedef unsigned long volatile const		rsvp_vcu32_t;      /* Read Only */

/* Volatile constant signed types - signal compiler don't cache these types */
typedef signed char volatile const			rsvp_vcs8_t;       /* Read Only */
typedef signed short volatile const			rsvp_vcs16_t;      /* Read Only */
typedef signed long volatile const			rsvp_vcs32_t;      /* Read Only */

/* Status-Node-Domain Types                                                 */
/* Note: It may be more efficient to specify these as U32 on ARM Cortex     */
/*       They are currently U16 to use less memory on 8 bit CPUs            */
typedef unsigned char						rsvp_boolean_t;
typedef unsigned short						rsvp_status_t;
typedef unsigned short						rsvp_timeout_t;
typedef unsigned short						rsvp_node_t;
typedef unsigned short						rsvp_domain_t;

/* Ranges of the defined Types                                              */
#define RSVP_U8_MIN     ((u8)0)
#define RSVP_U8_MAX     ((u8)255)
#define RSVP_S8_MIN     ((s8)-128)
#define RSVP_S8_MAX     ((s8)127)
#define RSVP_U16_MIN    ((u16)0u)
#define RSVP_U16_MAX    ((u16)65535u)
#define RSVP_S16_MIN    ((s16)-32768)
#define RSVP_S16_MAX    ((s16)32767)
#define RSVP_U32_MIN    ((u32)0uL)
#define RSVP_U32_MAX    ((u32)4294967295uL)
#define RSVP_S32_MIN    ((s32)-2147483648)
#define RSVP_S32_MAX    ((s32)2147483647)
/*--------------------------------------------------------------------------*/
#else
	#error "Undefined C Compiler - not one of Imagecraft, Hi-Tech, Keil/C51, ARM CC, GNU C ?"
#endif
/*--------------------------------------------------------------------------*/

/****************************************************************************/
/* Type Definitions that are specific to each Compiler                      */
/****************************************************************************/
/*--------------------------------------------------------------------------*/
/* ImageCraft C Compiler                                                    */
/*                                                                          */
/* Note that if the compiler setting "treat const as flash" is true         */
/* then these defines will behave exactly as their corresponding "const"    */
/* types. If the compiler setting "treat const as SRAM" is true             */
/* then they will behave differently (types below will be in flash memory)  */
/*--------------------------------------------------------------------------*/
#if defined(__IMAGECRAFT__)
/* Basic flash unsigned types                                               */
typedef unsigned char __flash				rsvp_fu8_t;        /* Read Only */
typedef unsigned short __flash				rsvp_fu16_t;       /* Read Only */
typedef unsigned long __flash				rsvp_fu32_t;       /* Read Only */
/* Basic flash signed types                                                 */
typedef signed char __flash					rsvp_fs8_t;        /* Read Only */
typedef signed short __flash				rsvp_fs16_t;       /* Read Only */
typedef signed long __flash					rsvp_fs32_t;       /* Read Only */
/* Volatile flash unsigned types - signals compiler don't cache these types */
typedef unsigned char volatile __flash		rsvp_vfu8_t;       /* Read Only */
typedef unsigned short volatile __flash		rsvp_vfu16_t;      /* Read Only */
typedef unsigned long volatile __flash		rsvp_vfu32_t;      /* Read Only */
/* Volatile flash signed types - signals compiler don't cache these types   */
typedef signed char volatile __flash		rsvp_vfs8_t;       /* Read Only */
typedef signed short volatile __flash		rsvp_vfs16_t;      /* Read Only */
typedef signed long volatile __flash		rsvp_vfs32_t;      /* Read Only */
/*--------------------------------------------------------------------------*/
/* Keil C51/CX51 C Compiler                                                 */
/*                                                                          */
/* For the i8051 compiler the "code" directive indicates flash memory is    */
/* to be used for these types.                                              */
/*--------------------------------------------------------------------------*/
#elif defined(__C51__) || defined(__CX51__)
/* Basic flash unsigned types                                               */
typedef unsigned char const code			rsvp_fu8_t;        /* Read Only */
typedef unsigned short const code			rsvp_fu16_t;       /* Read Only */
typedef unsigned long const code			rsvp_fu32_t;       /* Read Only */
/* Basic flash signed types                                                 */
typedef signed char const code				rsvp_fs8_t;        /* Read Only */
typedef signed short const code				rsvp_fs16_t;       /* Read Only */
typedef signed long const code				rsvp_fs32_t;       /* Read Only */
/* Volatile flash unsigned types - signals compiler don't cache these types */
typedef unsigned char volatile const code	rsvp_vfu8_t;       /* Read Only */
typedef unsigned short volatile const code	rsvp_vfu16_t;      /* Read Only */
typedef unsigned long volatile const code	rsvp_vfu32_t;      /* Read Only */
/* Volatile flash signed types - signals compiler don't cache these types   */
typedef signed char volatile const code		rsvp_vfs8_t;       /* Read Only */
typedef signed short volatile const code	rsvp_vfs16_t;      /* Read Only */
typedef signed long volatile const code		rsvp_vfs32_t;      /* Read Only */
/*--------------------------------------------------------------------------*/
/* "Other" Compilers that use "const" to indicate flash memory              */
/*                                                                          */
/* Note that the effect of these types is generally the same as the const   */
/* types above, however the intent of using them is to be specific that     */
/* they are intended to be located in flash memory, and not just "constant" */
/*--------------------------------------------------------------------------*/
#elif defined(__GNUC__) || defined(HI_TECH_C) || defined(__CC_ARM)
/* Basic flash unsigned types                                               */
typedef unsigned char const					rsvp_fu8_t;        /* Read Only */
typedef unsigned short const				rsvp_fu16_t;       /* Read Only */
typedef unsigned long const					rsvp_fu32_t;       /* Read Only */
/* Basic flash signed types                                                 */
typedef signed char const					rsvp_fs8_t;        /* Read Only */
typedef signed short const					rsvp_fs16_t;       /* Read Only */
typedef signed long const					rsvp_fs32_t;       /* Read Only */
/* Volatile flash unsigned types - signals compiler don't cache these types */
typedef unsigned char volatile const		rsvp_vfu8_t;       /* Read Only */
typedef unsigned short volatile const		rsvp_vfu16_t;      /* Read Only */
typedef unsigned long volatile const		rsvp_vfu32_t;      /* Read Only */
/* Volatile flash signed types - signals compiler don't cache these types   */
typedef signed char volatile const			rsvp_vfs8_t;       /* Read Only */
typedef signed short volatile const			rsvp_vfs16_t;      /* Read Only */
typedef signed long volatile const			rsvp_vfs32_t;      /* Read Only */
/*--------------------------------------------------------------------------*/
#else
	#error "Undefined C Compiler - not one of Imagecraft, Hi-Tech, Keil/C51, ARM CC, GNU C ?"
#endif
/*--------------------------------------------------------------------------*/

/*! \ingroup rsvp_types
 *  \brief Function Return codes used by rsvp system
 */
typedef enum
{
    RSVP_SUCCESS,                /*!< success = no errors             */
    RSVP_TIMEOUT,                /*!< timeout occurred                */
    RSVP_ILL_ARG,                /*!< illegal argument                */
    RSVP_ILL_CMD,                /*!< illegal command                 */
    RSVP_ILL_STATE,              /*!< illegal state                   */
	RSVP_ILL_ADDR,               /*!< illegal address                 */
    RSVP_ILL_IO,                 /*!< illegal I/O operation           */
    RSVP_NO_RESOURCE,            /*!< insufficient resource           */
    RSVP_ERR_PLATFORM,           /*!< platform or porting layer error */
    RSVP_ERR_IO ,                /*!< general I/O system error        */
	RSVP_FAIL                    /*!< general failure - cause unknown */
} rsvp_RetCode_t;

#ifdef __cplusplus
} 
#endif /* __cplusplus */
#endif /* __RSVP_TYPES_H__ */
/* End of File : rsvp_types.h */

